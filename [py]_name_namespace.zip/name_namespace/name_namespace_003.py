import showattr as sa

value = 3
def F1() : 
    value = 10
    def F1_inner() : 
        print('value at F1_inner = ', value)
        return locals()
    sa.show_function_local('F1_inner function', F1_inner, F1_inner())
    return locals()        


sa.show_module('current module', globals())
sa.show_function_local('F1 function', F1, F1())
#sa.show_code('F1.__code__', F1.__code__)
