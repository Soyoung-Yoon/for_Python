
import showattr as sa

value = 3
def add_num1(num=1):
    value = value + num

def add_num2(num=1):
    print(value)
    value = value + num
    print(value)

print(value)
add_num1()
add_num2()
print(value)