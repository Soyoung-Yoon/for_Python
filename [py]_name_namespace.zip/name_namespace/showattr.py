def show_function(title, func) :
    attrs = {
        "__class__" : func.__class__,
        "__name__" : func.__name__,
        "__annotations__" : func.__annotations__,
        "__defaults__" : func.__defaults__,
        "__kwdefaults__" : func.__kwdefaults__ }

    print(title)
    for x in attrs.items():
        print('{:15} => {}'.format(*x))
    else : print()

def show_function_local(title, func, local) :
    attrs = {
        "__name__" : func.__name__,
        "__globals__" : func.__globals__,
        "__code__" : func.__code__,
        "__closure__" : func.__closure__ }

    mydict = dict(**attrs, **local)
    llist = []
    for x, y in mydict.items(): 
        if type(y) == int or type(y) == str :       
            llist.append((x, y))
        else :
            llist.append((x, type(y)))

    clo = attrs["__closure__"]
    if clo != None :
        for x, y in zip(func.__code__.co_freevars, clo) :
            llist.append( ("=> co_freevars : " + x, y.cell_contents))

    print(title)
    for a, b in llist:
        print('{:11} - {}'.format(a, b))
    else : print()

def show_code(title, code) :
    attrs = {
        "__class__": code.__class__,
        "co_name" : code.co_name,
        "co_nlocals" : code.co_nlocals,
        "co_varnames" : code.co_varnames,
        "co_consts" : code.co_consts,
        "co_kwonlyargcount": code.co_kwonlyargcount,
        "co_freevars" : code.co_cellvars,
        "co_cellvars" : code.co_cellvars }  

    print(title)
    for x in attrs.items():
        print('{:17} => {}'.format(*x))
    else : print()

def show_module(title, mobj):
    nlist = ['__name__', '__builtins__']
    llist = []
    for x, v in mobj.items():
        if x in nlist or not x.startswith('_'):
            if type(v) == int or type(v) == str :
                llist.append((x, v))
            else:
                llist.append((x, type(v)))

    print(title)
    for a, b in llist:
        print('{:12} - {}'.format(a, b))
    else : print()



    

