import showattr as sa

def add_ret(a, b):
    c = a + b   
    return c, locals()

r = add_ret(10, 20)
sa.show_module('module', globals())
sa.show_function_local('add_ret function', add_ret, add_ret(1, 2)[1])