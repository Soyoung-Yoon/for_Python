import os

fileR = 'C:\\MyPythonFiles\\mydata2.txt'
fileW = 'C:\\MyPythonFiles\\mydata2T.txt'


def exchangeCols(data, c1, c2):
    for x in data:
        x[c1], x[c2] = x[c2], x[c1]

def deleteColumn(data, c):
    for x in data:
        del x[c]
        
if os.path.exists(fileR) :
    with open(fileR) as fr:
        data = [ x.split() for x in fr.readlines()] 
        exchangeCols(data, 1, 6)
        exchangeCols(data, 3, 4)        
        deleteColumn(data, -1)

    with open(fileW, 'w') as fw:
        fw.write('\n'.join( ' '.join(x) for x in data ))
            
    print(f"{fileR!r} transformation success!!")
else :
    print(f"{fileR!r} doesn\'t exist")
