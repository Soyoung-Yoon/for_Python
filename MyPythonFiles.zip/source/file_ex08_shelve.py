import shelve

with shelve.open('mydata') as mydata :
    fruits = ['orange', 'banana', 'apple']
    mydata['fruits'] = fruits
    mydata['scores'] = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    mydata['name'] = 'Julie Yoon'
    mydata['fruits'] = ['watermelon', 'mango']
    print(mydata['name'])
    print(mydata['fruits'])
    print(mydata['scores'])

mydata = shelve.open('mydata')
fruits = ['orange', 'banana', 'apple']
#mydata['fruits'] = fruits
#mydata['scores'] = [1, 2, 3, 4, 5, 6, 7, 8, 9]
#mydata['name'] = 'Julie Yoon'
#mydata['fruits'] = ['watermelon', 'mango']
print(mydata['name'])
print(mydata['fruits'])
print(mydata['scores'])
mydata.close()

