import os

file = 'C:\\MyPythonFiles\\letter.txt'
filecp = 'C:\\MyPythonFiles\\letter_cp.txt'
if os.access(file, os.F_OK) :
    with open(file) as rfp, open(filecp, 'w') as wfp:
            t = rfp.read()
            print(t)
            wfp.write(t)            
else :
    print("File not exist!")
