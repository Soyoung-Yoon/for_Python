import os

print(os.getcwd())
os.chdir('..')
print(os.getcwd())

os.chdir('C:\\MyPythonFiles\\TextFiles\\A')
print(os.getcwd())
os.chdir('..\\..\\..\\MyPythonScripts')
print(os.getcwd())
