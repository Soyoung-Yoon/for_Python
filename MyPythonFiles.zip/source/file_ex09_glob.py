
import os, glob

os.chdir('C:\\MyPythonFiles')
#print(glob.glob('.\\*'), end='\n\n')
#print(glob.glob('*.txt'), end='\n\n')
#print(glob.glob('TEMP\\[0-9]?.txt'), end='\n\n')
#print(glob.glob('temp\\[0-9]*.txt'), end='\n\n')
#print(glob.glob(os.path.abspath('.\\*.txt')))
if 0:
    a = glob.glob('*')
    print(type(a), a)
if 1:    
    a = glob.iglob('*')
    print(type(a), a)
    print(next(a))
    print(" ".join( a ))

