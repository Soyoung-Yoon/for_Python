with open('C:\\MyPythonFiles\\letter3.txt', 'w') as myfile:
    myfile.write('Take care! See u later~\n')
    raise KeyError
