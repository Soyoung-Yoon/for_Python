#여러 파일, 디렉터리 압축하기
# https://docs.python.org/3/library/zipfile.html  
if 0:
     import os, zipfile, glob

     os.chdir('C:\\MyPythonFiles\\source')
     if not os.path.exists('.\\ZIP') :
          os.mkdir('.\\ZIP')

     # path에 포함된 디렉터리가 없으면 Error 발생
     with zipfile.ZipFile('.\\ZIP\\myfiles.zip', 'w') as f:
          for fname in glob.glob('.\\*.py'):
               f.write(fname)
               print(fname)
          os.chdir('..')
          f.write('TEMP')
          for fname in glob.glob('TEMP\\*'):
               f.write(fname)
        
          
#압축파일 내 파일명 읽기, 압축 해제
if 0:
     import os, zipfile
     os.chdir('C:\\MyPythonFiles\\source')
     with zipfile.ZipFile('.\\ZIP\\myfiles.zip') as f:
          print(f.namelist())
          f.extract('file_ex10_zipfile.py', '.\\Extract')
          f.extractall('.\\ExtractALL')
          

# 한 개 디렉터리 압축
# https://docs.python.org/3/library/shutil.html
if 0:
     import os, shutil
     os.chdir('C:\\MyPythonFiles\\source')
     # path에 포함된 디렉터리가 없으면 생성됨
     shutil.make_archive('.\\ZAP\\myfolder',
                         'zip', '..\\TEMP')
     print("Done")
