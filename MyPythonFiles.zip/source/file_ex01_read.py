myfile = open('C:\\MyPythonFiles\\letter.txt')
mycont = myfile.read()
raise KeyError
print(type(mycont))
print(mycont)
myfile.close()

myfile = open('C:\\MyPythonFiles\\letter.txt')
mycont = myfile.readlines()
print(type(mycont))
print(mycont)
myfile.close()
