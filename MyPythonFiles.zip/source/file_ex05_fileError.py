file = 'NoFile'
if 0:
    try :
        with open(file) as fp:
            msg = fp.read()
            print(msg)
    except OSError:
        print("File doesn't exist or No read permission")
if 1:
    import os    
    if os.access(file, os.F_OK) and os.access(file, os.R_OK):
        with open(file) as fp:
            msg = fp.read()
            print(msg)
    else:
        print("File doesn't exist or No read permission")
        
