
myfile = open('C:\\MyPythonFiles\\letter2.txt', 'w')
myfile.write('Take care! See u later~\n')
raise KeyError
myfile.close()
