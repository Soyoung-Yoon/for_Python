with open('C:\\MyPythonFiles\\letter.txt') as myfile:
    mycont = myfile.read()
    raise KeyError
    print(type(mycont))
    print(mycont)

with open('C:\\MyPythonFiles\\letter.txt') as myfile:
    mycont = myfile.readlines()
    print(type(mycont))
    print(mycont)
