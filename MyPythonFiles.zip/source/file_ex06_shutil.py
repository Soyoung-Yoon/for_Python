import shutil
#from shutil import copy
shutil.copy('C:\\MyPythonFiles\\letter.txt',
            '.\\letter_cp2.txt')

from distutils.dir_util import copy_tree
copy_tree('C:\\MyPythonFiles\\TextFiles',
          '.\\TextFiles')
