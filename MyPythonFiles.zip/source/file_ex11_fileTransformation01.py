import os

fileR = 'C:\\MyPythonFiles\\mydata.txt'
fileW = 'C:\\MyPythonFiles\\mydataT.txt'

if os.path.exists(fileR) :
    with open(fileR) as fr:
        data = fr.readlines()
        
    data = data[3:]
    data = [ x.split(maxsplit=1)[1] for x in data]        
    data.sort(key=len)
    data.append('Good Luck to you!\n')
    data = [ f'{i} {x}' for i, x in enumerate(data, start=1)]
        
    print(data)
    
    with open(fileW, 'w') as fw:
        fw.write(''.join(data))

    print(f"{fileR!r} transformation success!!")
else :
    print(f"{fileR!r} doesn\'t exist")

