
from mypackage import *

print(a.add(5, 3))
print(b.add(10, 20))
print(c.add(1, 17))

'''
import sys

for path in sys.path:
    print(path)
'''    



